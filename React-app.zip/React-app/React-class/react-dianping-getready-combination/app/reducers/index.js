import { combineReducers } from 'redux'
import userinfo from './userinfo'

export default combineReducers({
    userinfo
})