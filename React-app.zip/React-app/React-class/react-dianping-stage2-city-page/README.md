# react-simple-o2o-demo

选择城市页面，文档参见[这里](./docs/README.md)